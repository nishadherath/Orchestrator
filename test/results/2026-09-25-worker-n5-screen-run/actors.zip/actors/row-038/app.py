import json
import re
import sys

DECIMAL = re.compile(r"[0-9]+")
MIN_PORT = 1
MAX_PORT = 65535
ERROR = "invalid"


def parse_port(value):
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        number = value
    elif isinstance(value, str):
        text = value.strip()
        if not DECIMAL.fullmatch(text):
            return None
        number = int(text)
    else:
        return None
    if not MIN_PORT <= number <= MAX_PORT:
        return None
    return number


def solve(data):
    value = data.get("port") if isinstance(data, dict) else None
    port = parse_port(value)
    if port is None:
        return {"port": None, "error": ERROR}
    return {"port": port, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
