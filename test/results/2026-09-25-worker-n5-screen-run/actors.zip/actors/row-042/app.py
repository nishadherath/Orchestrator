import json
import sys

PORT_MIN = 1
PORT_MAX = 65535


def validate_port(value):
    """Validate a service port setting.

    Accepts an int, or a string holding a decimal integer with optional
    surrounding whitespace. Returns (port, None) when valid, otherwise
    (None, error_message).
    """
    if value is None:
        return None, "port is required"
    if isinstance(value, bool):
        return None, "port must be an integer, not a boolean"
    if isinstance(value, int):
        port = value
    elif isinstance(value, str):
        text = value.strip()
        if not text:
            return None, "port must not be blank"
        if not text.isascii() or not text.isdigit():
            return None, "port must be a decimal integer"
        port = int(text)
    else:
        return None, "port must be an integer or a decimal string"
    if port < PORT_MIN or port > PORT_MAX:
        return None, "port must be between %d and %d" % (PORT_MIN, PORT_MAX)
    return port, None


def solve(data):
    # Accept either the raw setting value or an object with a "port" key.
    value = data.get("port") if isinstance(data, dict) else data
    port, error = validate_port(value)
    return {"port": port, "error": error}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
