import json
import sys


def solve(data):
    stock = data["stock"]
    working = dict(stock)
    seen = set()

    for change in data.get("changes", []):
        cid = change["id"]
        if cid in seen:
            return {"stock": stock, "error": "duplicate_id"}
        seen.add(cid)

        delta = change["delta"]
        if isinstance(delta, bool) or not isinstance(delta, int):
            return {"stock": stock, "error": "invalid_delta"}

        sku = change["sku"]
        new = working.get(sku, 0) + delta
        if new < 0:
            return {"stock": stock, "error": "negative_stock"}
        working[sku] = new

    return {"stock": working, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
