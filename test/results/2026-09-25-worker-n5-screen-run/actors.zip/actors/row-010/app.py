import json
import re
import sys


def solve(data):
    value = data.get("port")
    if isinstance(value, bool) or value is None:
        return {"port": None, "error": "invalid port"}

    if isinstance(value, int):
        port = value
    elif isinstance(value, str):
        s = value.strip()
        if not re.fullmatch(r"\d+", s):
            return {"port": None, "error": "invalid port"}
        port = int(s)
    else:
        return {"port": None, "error": "invalid port"}

    if 1 <= port <= 65535:
        return {"port": port, "error": None}
    return {"port": None, "error": "invalid port"}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
