import json
import re
import sys

MIN_PORT = 1
MAX_PORT = 65535
DECIMAL = re.compile(r"[+-]?[0-9]+\Z")


def solve(data):
    value = data.get("port") if isinstance(data, dict) else None

    if isinstance(value, bool) or value is None:
        return {"port": None, "error": "invalid port"}

    if isinstance(value, int):
        port = value
    elif isinstance(value, str):
        token = value.strip()
        if not DECIMAL.match(token):
            return {"port": None, "error": "invalid port"}
        port = int(token)
    else:
        return {"port": None, "error": "invalid port"}

    if not MIN_PORT <= port <= MAX_PORT:
        return {"port": None, "error": "invalid port"}

    return {"port": port, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
