import json
import sys


def solve(data):
    stock = dict(data.get("stock") or {})
    changes = data.get("changes") or []

    seen = set()
    pending = dict(stock)
    for change in changes:
        cid = change.get("id")
        if cid in seen:
            return {"stock": stock, "error": "duplicate_id"}
        seen.add(cid)

        delta = change.get("delta")
        if isinstance(delta, bool) or not isinstance(delta, int):
            return {"stock": stock, "error": "invalid_delta"}

        sku = change.get("sku")
        new_qty = pending.get(sku, 0) + delta
        if new_qty < 0:
            return {"stock": stock, "error": "negative_stock"}
        pending[sku] = new_qty

    return {"stock": pending, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
