import json
import sys

MIN_PORT = 1
MAX_PORT = 65535


def _ok(port):
    return {"port": port, "error": None}


def _fail(message):
    return {"port": None, "error": message}


def solve(data):
    """Validate a service port setting.

    ``data`` may be a JSON object carrying a ``port`` key, or the raw
    setting value itself. A valid setting is an integer or a string
    containing a decimal integer (surrounding whitespace allowed) in the
    range 1..65535. Booleans, missing values, blank or non-decimal strings,
    and out-of-range values are rejected.
    """
    if isinstance(data, dict):
        if "port" not in data:
            return _fail("port is missing")
        value = data["port"]
    else:
        value = data

    if value is None:
        return _fail("port is missing")

    if isinstance(value, bool):
        return _fail("port must not be a boolean")

    if isinstance(value, int):
        port = value
    elif isinstance(value, str):
        text = value.strip()
        if not text:
            return _fail("port must not be blank")
        if not text.isascii() or not text.isdigit():
            return _fail("port must be a decimal integer")
        port = int(text)
    else:
        return _fail("port must be an integer or a decimal string")

    if port < MIN_PORT or port > MAX_PORT:
        return _fail("port must be between %d and %d" % (MIN_PORT, MAX_PORT))

    return _ok(port)


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
