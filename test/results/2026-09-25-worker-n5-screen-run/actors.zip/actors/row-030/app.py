import json
import re
import sys

DECIMAL = re.compile(r"^[+-]?[0-9]+$")


def solve(data):
    value = data.get("port") if isinstance(data, dict) else None

    if isinstance(value, bool):
        return {"port": None, "error": "invalid_port"}

    if isinstance(value, int):
        port = value
    elif isinstance(value, str):
        text = value.strip()
        if not DECIMAL.match(text):
            return {"port": None, "error": "invalid_port"}
        port = int(text)
    else:
        return {"port": None, "error": "invalid_port"}

    if not 1 <= port <= 65535:
        return {"port": None, "error": "invalid_port"}

    return {"port": port, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
