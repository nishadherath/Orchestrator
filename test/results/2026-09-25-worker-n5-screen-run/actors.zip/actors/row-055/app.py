import json
import sys


def _is_valid_delta(delta):
    # bool is a subclass of int, so it must be excluded explicitly.
    return isinstance(delta, int) and not isinstance(delta, bool)


def solve(data):
    """Apply an inventory batch atomically.

    Changes are applied in order to a working copy of the stock. The first
    failure (duplicate id, invalid delta, or negative intermediate stock)
    rejects the whole batch and returns the original stock untouched.
    """
    original = data.get("stock") or {}
    changes = data.get("changes") or []

    working = dict(original)
    seen_ids = set()

    for change in changes:
        change_id = change.get("id")
        if change_id in seen_ids:
            return {"stock": original, "error": "duplicate_id"}
        seen_ids.add(change_id)

        delta = change.get("delta")
        if not _is_valid_delta(delta):
            return {"stock": original, "error": "invalid_delta"}

        sku = change.get("sku")
        new_level = working.get(sku, 0) + delta
        if new_level < 0:
            return {"stock": original, "error": "negative_stock"}
        working[sku] = new_level

    return {"stock": working, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
