import json
import sys

DUPLICATE_ID = "DUPLICATE_ID"
INVALID_DELTA = "INVALID_DELTA"
NEGATIVE_STOCK = "NEGATIVE_STOCK"


def _is_delta(value):
    return isinstance(value, int) and not isinstance(value, bool)


def _reject(data, code):
    return {"stock": dict(data["stock"]), "error": code}


def solve(data):
    changes = data.get("changes", [])

    # Batch-level checks first, in the order the codes are defined: a repeated
    # id beats a bad delta, and both beat anything the simulation finds.
    seen = set()
    for change in changes:
        if change.get("id") in seen:
            return _reject(data, DUPLICATE_ID)
        seen.add(change.get("id"))

    for change in changes:
        if not _is_delta(change.get("delta")):
            return _reject(data, INVALID_DELTA)

    stock = dict(data["stock"])
    for change in changes:
        sku = change["sku"]
        total = stock.get(sku, 0) + change["delta"]
        if total < 0:
            return _reject(data, NEGATIVE_STOCK)
        stock[sku] = total

    return {"stock": stock, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
