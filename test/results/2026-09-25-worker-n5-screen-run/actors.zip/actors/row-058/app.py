import json
import sys


PORT_MIN = 1
PORT_MAX = 65535
INVALID_PORT = "invalid port"


def _invalid():
    return {"port": None, "error": INVALID_PORT}


def solve(data):
    """Validate a service port setting supplied under the "port" key.

    Accepts an int, or a str holding a decimal integer with optional
    surrounding whitespace, in the range 1..65535. Booleans, missing or
    null values, blank or non-decimal strings, and out-of-range values
    are rejected.
    """
    if not isinstance(data, dict) or "port" not in data:
        return _invalid()

    value = data["port"]

    # bool is a subclass of int; it must be rejected explicitly.
    if value is None or isinstance(value, bool):
        return _invalid()

    if isinstance(value, int):
        port = value
    elif isinstance(value, str):
        digits = value.strip()
        # Only ASCII digits: no sign, underscores, dots, or Unicode digits.
        if not digits or not (digits.isascii() and digits.isdigit()):
            return _invalid()
        significant = digits.lstrip("0")
        # Anything longer than five significant digits exceeds PORT_MAX.
        if len(significant) > 5:
            return _invalid()
        port = int(significant or "0")
    else:
        return _invalid()

    if not PORT_MIN <= port <= PORT_MAX:
        return _invalid()

    return {"port": port, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
