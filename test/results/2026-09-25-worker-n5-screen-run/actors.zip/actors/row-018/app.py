import json
import re
import sys


def solve(data):
    if not isinstance(data, dict) or "port" not in data:
        return {"port": None, "error": "invalid_port"}

    value = data["port"]

    if isinstance(value, bool) or not isinstance(value, (int, str)):
        return {"port": None, "error": "invalid_port"}

    if isinstance(value, str):
        stripped = value.strip()
        if not re.fullmatch(r"[0-9]+", stripped):
            return {"port": None, "error": "invalid_port"}
        value = int(stripped)

    if not 1 <= value <= 65535:
        return {"port": None, "error": "invalid_port"}

    return {"port": value, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
