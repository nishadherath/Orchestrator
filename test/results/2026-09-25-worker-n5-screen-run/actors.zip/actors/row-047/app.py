import json
import sys


def solve(data):
    """Apply an inventory batch atomically.

    On any failure the original stock is returned unchanged alongside an
    error code; on success the new stock is returned with a null error.
    """
    original = data.get("stock") or {}
    changes = data.get("changes") or []

    def fail(code):
        return {"stock": dict(original), "error": code}

    stock = dict(original)
    seen = set()

    for change in changes:
        cid = change.get("id")
        if cid in seen:
            return fail("duplicate_id")
        seen.add(cid)

        delta = change.get("delta")
        if not isinstance(delta, int) or isinstance(delta, bool):
            return fail("invalid_delta")

        sku = change.get("sku")
        new_qty = stock.get(sku, 0) + delta
        if new_qty < 0:
            return fail("negative_stock")
        stock[sku] = new_qty

    return {"stock": stock, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
