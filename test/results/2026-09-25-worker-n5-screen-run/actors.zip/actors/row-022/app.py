import json
import sys


def solve(data):
    value = data.get("port") if isinstance(data, dict) else None
    if isinstance(value, bool) or value is None:
        return {"port": None, "error": "invalid"}
    if isinstance(value, int):
        port = value
    elif isinstance(value, str):
        text = value.strip()
        if not text.isdigit():
            return {"port": None, "error": "invalid"}
        port = int(text)
    else:
        return {"port": None, "error": "invalid"}
    if not 1 <= port <= 65535:
        return {"port": None, "error": "invalid"}
    return {"port": port, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
