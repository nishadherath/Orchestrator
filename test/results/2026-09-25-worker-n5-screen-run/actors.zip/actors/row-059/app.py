import json
import sys


DUPLICATE_ID = "duplicate_id"
INVALID_DELTA = "invalid_delta"
NEGATIVE_STOCK = "negative_stock"


def _is_valid_delta(delta):
    # bool is a subclass of int, so it has to be excluded explicitly.
    return isinstance(delta, int) and not isinstance(delta, bool)


def solve(data):
    """Apply a batch of inventory changes atomically.

    Changes are applied in order to a copy of ``data["stock"]``. A SKU that is
    not yet in stock starts at zero. If any change repeats an id, carries a
    non-integer delta, or drives a SKU below zero, the whole batch is rejected:
    the original stock is returned unchanged together with the matching error
    code. Otherwise the new stock is returned with a null error.
    """
    stock = data.get("stock") or {}
    changes = data.get("changes") or []

    new_stock = dict(stock)
    seen_ids = set()

    for change in changes:
        change_id = change.get("id")
        if change_id in seen_ids:
            return {"stock": stock, "error": DUPLICATE_ID}
        seen_ids.add(change_id)

        delta = change.get("delta")
        if not _is_valid_delta(delta):
            return {"stock": stock, "error": INVALID_DELTA}

        sku = change.get("sku")
        updated = new_stock.get(sku, 0) + delta
        if updated < 0:
            return {"stock": stock, "error": NEGATIVE_STOCK}
        new_stock[sku] = updated

    return {"stock": new_stock, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
