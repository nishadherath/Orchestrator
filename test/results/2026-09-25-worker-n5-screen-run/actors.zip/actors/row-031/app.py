import json
import sys


def solve(data):
    stock = dict(data["stock"])
    seen = set()

    for change in data.get("changes", []):
        cid = change.get("id")
        if cid in seen:
            return {"stock": data["stock"], "error": "duplicate_id"}
        seen.add(cid)

        delta = change.get("delta")
        if isinstance(delta, bool) or not isinstance(delta, int):
            return {"stock": data["stock"], "error": "invalid_delta"}

        sku = change.get("sku")
        total = stock.get(sku, 0) + delta
        if total < 0:
            return {"stock": data["stock"], "error": "negative_stock"}
        stock[sku] = total

    return {"stock": stock, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
