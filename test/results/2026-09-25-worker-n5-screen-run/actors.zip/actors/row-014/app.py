import json
import sys


def solve(data):
    value = data.get("port") if isinstance(data, dict) else None

    port = None
    if isinstance(value, bool):
        port = None
    elif isinstance(value, int):
        port = value
    elif isinstance(value, str):
        stripped = value.strip()
        if stripped.isdigit():
            port = int(stripped)

    if port is not None and 1 <= port <= 65535:
        return {"port": port, "error": None}
    return {"port": None, "error": "invalid_port"}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
