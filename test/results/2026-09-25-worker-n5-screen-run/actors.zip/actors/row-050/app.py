import json
import sys

MIN_PORT = 1
MAX_PORT = 65535

_INVALID = {"port": None, "error": "invalid_port"}


def _parse_port(value):
    """Return the port as an int, or None if the value is not a valid port."""
    # bool is a subclass of int; reject it explicitly.
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        port = value
    elif isinstance(value, str):
        text = value.strip()
        # Only plain ASCII decimal digits: no sign, no whitespace inside,
        # no unicode digits, no underscores, no exponent/decimal point.
        if not text or not text.isascii() or not text.isdigit():
            return None
        port = int(text)
    else:
        return None
    if MIN_PORT <= port <= MAX_PORT:
        return port
    return None


def solve(data):
    if not isinstance(data, dict) or "port" not in data:
        return dict(_INVALID)
    port = _parse_port(data["port"])
    if port is None:
        return dict(_INVALID)
    return {"port": port, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
