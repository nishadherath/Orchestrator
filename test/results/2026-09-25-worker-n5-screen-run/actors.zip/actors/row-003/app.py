import json
import sys


def solve(data):
    stock = {}
    seen = set()
    for change in data["changes"]:
        sku = change["id"]
        delta = change["delta"]

        if sku in seen:
            return {"stock": None, "error": "DUPLICATE_ID"}
        seen.add(sku)

        if isinstance(delta, bool) or not isinstance(delta, int):
            return {"stock": None, "error": "INVALID_DELTA"}

        current = stock.get(sku, 0)
        new_value = current + delta
        if new_value < 0:
            return {"stock": None, "error": "NEGATIVE_STOCK"}

        stock[sku] = new_value

    return {"stock": stock, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
