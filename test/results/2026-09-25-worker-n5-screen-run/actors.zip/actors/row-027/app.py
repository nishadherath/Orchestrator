import json
import sys


def solve(data):
    stock = dict(data["stock"])
    working = dict(stock)
    seen = set()

    for change in data["changes"]:
        cid = change["id"]
        if cid in seen:
            return {"stock": stock, "error": "duplicate_id"}
        seen.add(cid)

        delta = change["delta"]
        if isinstance(delta, bool) or not isinstance(delta, int):
            return {"stock": stock, "error": "invalid_delta"}

        sku = change["sku"]
        new_value = working.get(sku, 0) + delta
        if new_value < 0:
            return {"stock": stock, "error": "negative_stock"}
        working[sku] = new_value

    return {"stock": working, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
