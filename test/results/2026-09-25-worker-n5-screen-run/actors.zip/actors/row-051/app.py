import json
import sys


def solve(data):
    """Apply an inventory batch atomically.

    Changes are applied in order to a working copy of ``stock``. If any change
    is rejected (duplicate id, invalid delta, or negative intermediate stock),
    the original stock is returned unchanged with the matching error code.
    """
    original = data.get("stock") or {}
    changes = data.get("changes") or []

    stock = dict(original)
    seen_ids = set()

    for change in changes:
        change_id = change.get("id")
        if change_id in seen_ids:
            return {"stock": original, "error": "duplicate_id"}
        seen_ids.add(change_id)

        delta = change.get("delta")
        if isinstance(delta, bool) or not isinstance(delta, int):
            return {"stock": original, "error": "invalid_delta"}

        sku = change.get("sku")
        new_level = stock.get(sku, 0) + delta
        if new_level < 0:
            return {"stock": original, "error": "negative_stock"}
        stock[sku] = new_level

    return {"stock": stock, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
