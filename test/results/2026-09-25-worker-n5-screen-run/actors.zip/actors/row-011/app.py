import json
import sys


def solve(data):
    stock = data["stock"]
    working = dict(stock)
    seen_ids = set()

    for change in data["changes"]:
        change_id = change["id"]
        if change_id in seen_ids:
            return {"stock": stock, "error": "duplicate_id"}
        seen_ids.add(change_id)

        delta = change["delta"]
        if isinstance(delta, bool) or not isinstance(delta, int):
            return {"stock": stock, "error": "invalid_delta"}

        sku = change["sku"]
        new_qty = working.get(sku, 0) + delta
        if new_qty < 0:
            return {"stock": stock, "error": "negative_stock"}
        working[sku] = new_qty

    return {"stock": working, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
