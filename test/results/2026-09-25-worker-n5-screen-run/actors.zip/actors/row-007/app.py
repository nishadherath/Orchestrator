import json
import sys


def solve(data):
    stock = dict(data.get("stock", {}))
    seen_ids = set()

    for change in data["changes"]:
        change_id = change["id"]
        delta = change["delta"]

        if change_id in seen_ids:
            return {"stock": data.get("stock", {}), "error": "DUPLICATE_ID"}
        seen_ids.add(change_id)

        if not isinstance(delta, int) or isinstance(delta, bool):
            return {"stock": data.get("stock", {}), "error": "INVALID_DELTA"}

        new_stock = stock.get(change_id, 0) + delta
        if new_stock < 0:
            return {"stock": data.get("stock", {}), "error": "NEGATIVE_STOCK"}

        stock[change_id] = new_stock

    return {"stock": stock, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
