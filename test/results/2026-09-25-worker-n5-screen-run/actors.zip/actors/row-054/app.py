import json
import re
import sys

MIN_PORT = 1
MAX_PORT = 65535

# A decimal integer: optional sign followed by ASCII digits only. Using an
# explicit pattern (rather than int() or str.isdigit()) keeps out things like
# "8_080", "1e3", "0x1F", or non-ASCII digit characters.
_DECIMAL_INT = re.compile(r"^[+-]?[0-9]+$")


def _ok(port):
    return {"port": port, "error": None}


def _fail(message):
    return {"port": None, "error": message}


def solve(data):
    """Validate a service port setting.

    ``data`` is expected to be a mapping with a ``"port"`` key. The value may be
    an integer, or a string containing a decimal integer with optional
    surrounding whitespace. Ports 1 through 65535 are valid.

    Returns ``{"port": <int>, "error": None}`` for a valid setting, or
    ``{"port": None, "error": <reason>}`` otherwise.
    """
    if not isinstance(data, dict) or "port" not in data:
        return _fail("port is required")

    value = data["port"]

    if value is None:
        return _fail("port is required")

    # bool is a subclass of int in Python, so it must be rejected explicitly
    # before the integer check.
    if isinstance(value, bool):
        return _fail("port must be an integer, not a boolean")

    if isinstance(value, int):
        port = value
    elif isinstance(value, str):
        text = value.strip()
        if not text:
            return _fail("port must not be blank")
        if not _DECIMAL_INT.match(text):
            return _fail("port must be a decimal integer")
        port = int(text)
    else:
        return _fail("port must be an integer or a decimal integer string")

    if port < MIN_PORT or port > MAX_PORT:
        return _fail(
            "port must be between %d and %d" % (MIN_PORT, MAX_PORT)
        )

    return _ok(port)


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
