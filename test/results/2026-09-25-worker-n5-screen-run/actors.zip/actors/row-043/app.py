import json
import sys


def solve(data):
    original = data.get("stock") or {}
    changes = data.get("changes") or []
    stock = dict(original)
    seen = set()

    for change in changes:
        cid = change.get("id")
        if cid in seen:
            return {"stock": original, "error": "duplicate_id"}
        seen.add(cid)

        delta = change.get("delta")
        if isinstance(delta, bool) or not isinstance(delta, int):
            return {"stock": original, "error": "invalid_delta"}

        sku = change.get("sku")
        new_value = stock.get(sku, 0) + delta
        if new_value < 0:
            return {"stock": original, "error": "negative_stock"}
        stock[sku] = new_value

    return {"stock": stock, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
