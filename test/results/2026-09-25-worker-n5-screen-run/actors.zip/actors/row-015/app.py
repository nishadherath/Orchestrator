import json
import sys


def solve(data):
    stock = dict(data["stock"])
    seen_ids = set()
    for change in data["changes"]:
        cid = change["id"]
        if cid in seen_ids:
            return {"stock": data["stock"], "error": "duplicate_id"}
        seen_ids.add(cid)

        delta = change["delta"]
        if isinstance(delta, bool) or not isinstance(delta, int):
            return {"stock": data["stock"], "error": "invalid_delta"}

        sku = change["sku"]
        new_qty = stock.get(sku, 0) + delta
        if new_qty < 0:
            return {"stock": data["stock"], "error": "negative_stock"}
        stock[sku] = new_qty

    return {"stock": stock, "error": None}


if __name__ == "__main__":
    print(json.dumps(solve(json.loads(sys.stdin.readline()))))
