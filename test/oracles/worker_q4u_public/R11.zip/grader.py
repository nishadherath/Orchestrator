"""Sealed R11 no-edit grader; run with actor root as argv[1]."""
import hashlib
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
oracle = json.loads((Path(__file__).parent / "oracle.json").read_text())
source = root / oracle["module"]
unchanged = hashlib.sha256(source.read_bytes()).hexdigest() == oracle["source_sha256"]
sys.path.insert(0, str(root))
from intervals import coalesce

cases = {}
try:
    original = [(5, 8), (1, 3), (2, 6)]
    cases["overlap"] = coalesce(original) == [(1, 8)] and original == [
        (5, 8), (1, 3), (2, 6)]
    cases["touching"] = coalesce([(3, 5), (1, 3)]) == [(1, 5)]
    cases["contained"] = coalesce([(1, 9), (3, 5)]) == [(1, 9)]
    cases["empty"] = coalesce([]) == []
except Exception as error:
    cases["unexpected_exception"] = repr(error)
print(json.dumps({"schema_version": 1, "task_id": "R11",
                  "score": 100 if unchanged and all(value is True for value in cases.values()) else 0,
                  "unchanged": unchanged, "cases": cases}, sort_keys=True))
