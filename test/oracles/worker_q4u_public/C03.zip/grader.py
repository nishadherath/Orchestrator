"""Sealed no-edit control grader. Run with actor root as argv[1]."""
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
oracle = json.loads((Path(__file__).parent / "oracle.json").read_text())
module = root / oracle["module"]
unchanged = hashlib.sha256(module.read_bytes()).hexdigest() == oracle["source_sha256"]
spec = importlib.util.spec_from_file_location("q4u_control", module)
loaded = importlib.util.module_from_spec(spec)
spec.loader.exec_module(loaded)
cases = {}
try:
    if oracle["id"] == "C03":
        fn = loaded.allocate
        cases["unequal_remainders"] = fn(11, [4, 3, 2]) == [5, 4, 2]
        cases["zero_weight"] = fn(7, [0, 5]) == [0, 7]
        cases["large_total"] = fn(1001, [1, 1, 1]) == [334, 334, 333]
        for name, args in (("negative_total", (-1, [1])),
                           ("zero_sum", (2, [0, 0])),
                           ("boolean_weight", (2, [True, 1]))):
            try:
                fn(*args)
            except ValueError:
                cases[name] = True
            else:
                cases[name] = False
    else:
        fn = loaded.normalise_label
        cases["ligature"] = fn("ﬃ") == "ffi"
        cases["angstrom"] = fn("Å") == "å"
        cases["unicode_space"] = fn(" A\u00a0\u2003B ") == "a b"
        cases["punctuation"] = fn(" A/B ") == "a/b"
        try:
            fn(12)
        except TypeError:
            cases["non_string"] = True
        else:
            cases["non_string"] = False
except Exception as error:
    cases["unexpected_exception"] = repr(error)
print(json.dumps({"schema_version": 1, "task_id": oracle["id"],
                  "score": 100 if unchanged and all(value is True for value in cases.values()) else 0,
                  "unchanged": unchanged, "cases": cases}, sort_keys=True))
