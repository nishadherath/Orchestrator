"""Sealed R09 grader; run with actor root as argv[1]."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(sys.argv[1]).resolve()))
from frame_parser import frames

cases = {}
for name, chunks, expected in (
    ("ordinary", [b"first\nsecond"], [b"first", b"second"]),
    ("cross_chunk", [b"he", b"llo"], [b"hello"]),
    ("final_delimiter", [b"one\n"], [b"one"]),
):
    try:
        cases[name] = frames(chunks) == expected
    except Exception:
        cases[name] = False
weights = {"ordinary": 30, "cross_chunk": 35, "final_delimiter": 35}
print(json.dumps({"schema_version": 1, "score": sum(weights[name]
                  for name, passed in cases.items() if passed),
                  "cases": cases, "weights": weights}, sort_keys=True))
