"""Split a stream of byte chunks into newline-delimited frames."""


def frames(chunks: list[bytes]) -> list[bytes]:
    result = []
    buffer = b""
    for chunk in chunks:
        buffer += chunk
        while b"\n" in buffer:
            frame, buffer = buffer.split(b"\n", 1)
            result.append(frame)
    if buffer:
        result.append(buffer)
    return result
