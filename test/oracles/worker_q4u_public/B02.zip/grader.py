"""Exploratory boltons JSONLIterator grader with bounded reads."""
from __future__ import annotations

import json
from io import StringIO

from boltons.jsonutils import JSONLIterator


class BoundedRead:
    def __init__(self, source: StringIO, limit: int = 16) -> None:
        self.source = source
        self.limit = limit
        self.reads = 0

    def read(self, size: int = -1) -> str:
        self.reads += 1
        if self.reads > self.limit:
            raise RuntimeError("bounded read limit exceeded")
        return self.source.read(size)

    def __iter__(self):
        return iter(self.source)

    def __getattr__(self, name: str):
        return getattr(self.source, name)


def values(text: str, rel_seek: float | None = None, reverse: bool = False) -> list[dict]:
    return list(JSONLIterator(BoundedRead(StringIO(text)), rel_seek=rel_seek,
                              reverse=reverse))


def safe(call) -> bool:
    try:
        return bool(call())
    except (RuntimeError, ValueError, OSError):
        return False


def main() -> None:
    data = "".join(json.dumps({"index": i}) + "\n" for i in range(12))
    no_trailer = '{"index": 0}\n{"index": 1}\n{"index": 2}'
    positive = values(data, rel_seek=0.6)
    cases = {
        "mid_final_line_terminates": safe(lambda: values(no_trailer, rel_seek=0.95) == []),
        "negative_seek_matches_positive": safe(
            lambda: values(data, rel_seek=-0.4) == positive and bool(positive)),
        "positive_seek_keeps_tail": safe(lambda: values(data, rel_seek=0.6) == positive
                                         and bool(positive)),
        "full_forward": safe(lambda: values(data) == [{"index": i} for i in range(12)]),
    }
    weights = {"mid_final_line_terminates": 35,
               "negative_seek_matches_positive": 35,
               "positive_seek_keeps_tail": 15,
               "full_forward": 15}
    print(json.dumps({"schema_version": 1, "cases": cases, "weights": weights,
                      "score": sum(weights[name] for name, passed in cases.items()
                                   if passed)}, sort_keys=True))


if __name__ == "__main__":
    main()
