"""Sealed H08 grader; run with actor root as argv[1]."""
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root))
from reconcile import apply_events

cases = {}
try:
    original = {"a": (1, "old")}
    cases["newer_put"] = (apply_events(original, [("a", 2, "put", "new")]) ==
                          {"a": (2, "new")} and original == {"a": (1, "old")})
except Exception:
    cases["newer_put"] = False
try:
    cases["stale_update"] = apply_events({"a": (5, "latest")},
                                           [("a", 4, "put", "old")]) == {
                                               "a": (5, "latest")}
except Exception:
    cases["stale_update"] = False
try:
    cases["tombstone_blocks_resurrection"] = apply_events(
        {}, [("a", 7, "delete", None), ("a", 6, "put", "ghost")]) == {
            "a": (7, None)}
except Exception:
    cases["tombstone_blocks_resurrection"] = False
weights = {"newer_put": 30, "stale_update": 35,
           "tombstone_blocks_resurrection": 35}
print(json.dumps({"schema_version": 1, "score": sum(weights[name]
                  for name, passed in cases.items() if passed),
                  "cases": cases, "weights": weights}, sort_keys=True))
