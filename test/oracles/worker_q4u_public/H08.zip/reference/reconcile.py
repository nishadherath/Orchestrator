"""Apply ordered object events to a versioned snapshot."""


def apply_events(state: dict, events: list[tuple]) -> dict:
    updated = dict(state)
    for object_id, revision, operation, payload in events:
        if object_id in updated and revision <= updated[object_id][0]:
            continue
        if operation == "delete":
            updated[object_id] = (revision, None)
        elif operation == "put":
            updated[object_id] = (revision, payload)
        else:
            raise ValueError("unknown operation")
    return updated
