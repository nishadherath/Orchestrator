"""Sealed R10 grader; run with actor root as argv[1]."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(sys.argv[1]).resolve()))
from billing import invoice_total, tax_cents

cases = {}
for name, actual, expected in (
    ("ordinary", lambda: invoice_total([100], 1000), 110),
    ("half_up", lambda: tax_cents(1, 5000), 1),
    ("subtotal_once", lambda: invoice_total([1, 1], 5000), 3),
):
    try:
        cases[name] = actual() == expected
    except Exception:
        cases[name] = False
weights = {"ordinary": 30, "half_up": 35, "subtotal_once": 35}
print(json.dumps({"schema_version": 1, "score": sum(weights[name]
                  for name, passed in cases.items() if passed),
                  "cases": cases, "weights": weights}, sort_keys=True))
