"""Sealed F07 grader; run with actor root as argv[1]."""
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root))
from event_ref import decode, encode

cases = {}
try:
    cases["plain_round_trip"] = (encode(["tenant", "event", "42"]) ==
                                  "tenant|event|42" and
                                  decode("tenant|event|42") ==
                                  ["tenant", "event", "42"])
except Exception:
    cases["plain_round_trip"] = False
try:
    cases["escape_encoding"] = encode(["a|b", "c" + chr(92) + "d"]) == (
        "a" + chr(92) + "|b|c" + chr(92) * 2 + "d")
except Exception:
    cases["escape_encoding"] = False
try:
    result = decode("a" + chr(92) + "|b|c" + chr(92) * 2 + "d")
    correct = result == ["a|b", "c" + chr(92) + "d"]
    try:
        decode("unfinished" + chr(92))
    except ValueError:
        invalid = True
    else:
        invalid = False
    cases["escape_decoding"] = correct and invalid
except Exception:
    cases["escape_decoding"] = False
weights = {"plain_round_trip": 30, "escape_encoding": 35,
           "escape_decoding": 35}
print(json.dumps({"schema_version": 1, "score": sum(weights[name]
                  for name, passed in cases.items() if passed),
                  "cases": cases, "weights": weights}, sort_keys=True))
