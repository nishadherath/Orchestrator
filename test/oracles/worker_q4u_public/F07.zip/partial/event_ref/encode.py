"""Serialise event-reference components."""


def encode(parts: list[str]) -> str:
    return "|".join(part.replace(chr(92), chr(92) * 2).replace("|", chr(92) + "|")
                    for part in parts)
