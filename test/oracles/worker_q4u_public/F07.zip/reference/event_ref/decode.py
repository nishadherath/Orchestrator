"""Parse event-reference components."""


def decode(value: str) -> list[str]:
    parts, current = [], []
    escaped = False
    for char in value:
        if escaped:
            if char not in "|" + chr(92):
                raise ValueError("unknown escape")
            current.append(char)
            escaped = False
        elif char == chr(92):
            escaped = True
        elif char == "|":
            parts.append("".join(current))
            current = []
        else:
            current.append(char)
    if escaped:
        raise ValueError("trailing escape")
    parts.append("".join(current))
    return parts
