"""Evaluator-only D01 grader. Package into a non-indexed sealed archive."""
from __future__ import annotations

import json
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory

from dotenv import dotenv_values, set_key
from dotenv.parser import parse_stream


def round_trip(value: str) -> bool:
    with TemporaryDirectory() as directory:
        path = Path(directory) / ".env"
        path.write_text("KEEP=ok\n", encoding="utf-8")
        set_key(str(path), "VALUE", value)
        parsed = dotenv_values(path)
        return parsed.get("VALUE") == value and parsed.get("KEEP") == "ok"


def parser_boundary(quote: str) -> bool:
    slash = chr(92)
    raw = f"first={quote}tail{slash * 2}{quote}\nsecond={quote}ok{quote}"
    rows = list(parse_stream(StringIO(raw)))
    return (len(rows) == 2 and [row.key for row in rows] == ["first", "second"]
            and [row.value for row in rows] == ["tail" + slash, "ok"]
            and [row.original.line for row in rows] == [1, 2]
            and not any(row.error for row in rows))


def main() -> None:
    slash = chr(92)
    results = {
        "round_trip_double_slash": round_trip("C:" + slash * 2 + "Users"),
        "round_trip_quote_and_slash": round_trip("a" + slash * 2 + "'b"),
        "single_quote_boundary": parser_boundary("'"),
        "double_quote_boundary": parser_boundary('"'),
        "plain_and_single_slash_controls": (
            round_trip("plain") and round_trip("C:" + slash + "Users")),
    }
    weights = {"round_trip_double_slash": 20,
               "round_trip_quote_and_slash": 20,
               "single_quote_boundary": 25,
               "double_quote_boundary": 20,
               "plain_and_single_slash_controls": 15}
    print(json.dumps({"schema_version": 1, "cases": results,
                      "score": sum(weights[name] for name, passed in results.items()
                                   if passed), "weights": weights}, sort_keys=True))


if __name__ == "__main__":
    main()
